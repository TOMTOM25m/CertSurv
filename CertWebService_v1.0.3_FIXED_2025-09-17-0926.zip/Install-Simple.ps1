# Certificate WebService - Vereinfachte Installation
# Version: v1.0.3 | Datum: 2025-09-17
# PowerShell 5.1 kompatibel

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("ISO", "Exchange", "DomainController", "Application")]
    [string]$ServerType = "ISO",
    
    [Parameter(Mandatory=$false)]
    [int]$HttpPort = 9080,
    
    [Parameter(Mandatory=$false)]
    [int]$HttpsPort = 9443,
    
    [Parameter(Mandatory=$false)]
    [switch]$Force = $false
)

# Globale Variablen
$InstallPath = "C:\CertWebService"
$SiteName = "CertWebService"
$logFile = "C:\Temp\CertWebService-Install-$(Get-Date -Format 'yyyy-MM-dd').log"

# Logging-Funktion
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $logEntry = "$(Get-Date -Format 'HH:mm:ss') [$Level] $Message"
    Write-Host $logEntry -ForegroundColor $(if($Level -eq "ERROR"){"Red"} elseif($Level -eq "WARNING"){"Yellow"} else{"Green"})
    if (-not (Test-Path $logFile)) {
        New-Item -Path $logFile -ItemType File -Force | Out-Null
    }
    Add-Content -Path $logFile -Value $logEntry -Encoding UTF8
}

# Server-spezifische Ports
$ServerPorts = @{
    "ISO" = @{ Http = 9080; Https = 9443 }
    "Exchange" = @{ Http = 9081; Https = 9444 }
    "DomainController" = @{ Http = 9082; Https = 9445 }
    "Application" = @{ Http = 9083; Https = 9446 }
}

# Port-Überschreibung für Server-Typ
if ($ServerPorts.ContainsKey($ServerType)) {
    $HttpPort = $ServerPorts[$ServerType].Http
    $HttpsPort = $ServerPorts[$ServerType].Https
}

try {
    Write-Log "=== Certificate WebService Installation ==="
    Write-Log "Server-Typ: $ServerType (HTTP: $HttpPort, HTTPS: $HttpsPort)"
    
    # Administrator-Check
    if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
        throw "Administrator-Rechte erforderlich!"
    }
    
    # IIS-Features installieren
    Write-Log "Installiere IIS-Features..."
    $features = @(
        "IIS-WebServerRole",
        "IIS-WebServer", 
        "IIS-CommonHttpFeatures",
        "IIS-HttpErrors",
        "IIS-HttpLogging",
        "IIS-RequestFiltering",
        "IIS-StaticContent"
    )
    
    foreach ($feature in $features) {
        Write-Log "Aktiviere Feature: $feature"
        Enable-WindowsOptionalFeature -Online -FeatureName $feature -All -NoRestart | Out-Null
    }
    
    # Installations-Verzeichnis erstellen
    Write-Log "Erstelle Installations-Verzeichnis: $InstallPath"
    if (Test-Path $InstallPath) {
        if ($Force) {
            Remove-Item -Path $InstallPath -Recurse -Force
        } else {
            throw "Verzeichnis '$InstallPath' existiert bereits. Verwenden Sie -Force zum Überschreiben."
        }
    }
    New-Item -Path $InstallPath -ItemType Directory -Force | Out-Null
    
    # WebService-Dateien kopieren
    Write-Log "Kopiere WebService-Dateien..."
    $sourceFiles = @(
        "WebService\certificates.json",
        "WebService\health.json", 
        "WebService\summary.json",
        "WebService\index.html"
    )
    
    foreach ($file in $sourceFiles) {
        $sourcePath = Join-Path $PSScriptRoot $file
        $destPath = Join-Path $InstallPath (Split-Path $file -Leaf)
        if (Test-Path $sourcePath) {
            Copy-Item -Path $sourcePath -Destination $destPath -Force
            Write-Log "Kopiert: $(Split-Path $file -Leaf)"
        } else {
            Write-Log "Datei nicht gefunden: $file" "WARNING"
        }
    }
    
    # IIS-Site erstellen
    Write-Log "Erstelle IIS-Site: $SiteName"
    Import-Module WebAdministration -ErrorAction SilentlyContinue
    
    # Port-Konflikt prüfen
    $existingBinding = Get-WebBinding | Where-Object { $_.bindingInformation -like "*:$HttpPort`:*" }
    if ($existingBinding -and -not $Force) {
        throw "Port $HttpPort bereits von '$($existingBinding.ItemXPath)' verwendet. Verwenden Sie -Force zum Überschreiben."
    }
    
    # Alte Site entfernen falls vorhanden
    if (Get-Website -Name $SiteName -ErrorAction SilentlyContinue) {
        Remove-Website -Name $SiteName
        Write-Log "Alte Site entfernt"
    }
    
    # Bestehende Binding auf Port entfernen falls vorhanden
    if ($existingBinding -and $Force) {
        Write-Log "Entferne bestehende Binding auf Port $HttpPort"
        Remove-WebBinding -HostHeader "" -Port $HttpPort -Protocol "http" -ErrorAction SilentlyContinue
    }
    
    # Neue Site erstellen
    try {
        New-Website -Name $SiteName -PhysicalPath $InstallPath -Port $HttpPort | Out-Null
        Write-Log "IIS-Site erstellt auf Port $HttpPort"
    } catch {
        Write-Log "Fehler beim Erstellen der Site: $($_.Exception.Message)" "WARNING"
        # Versuche alternative Methode
        Write-Log "Versuche alternative Site-Erstellung..."
        New-Item "IIS:\Sites\$SiteName" -bindings @{protocol="http";bindingInformation="*:$HttpPort`:"} -physicalPath $InstallPath
        Write-Log "IIS-Site über alternative Methode erstellt"
    }
    
    # Firewall-Regeln
    Write-Log "Konfiguriere Firewall..."
    $firewallRules = @(
        @{ Name = "CertWebService-HTTP-$HttpPort"; Port = $HttpPort; Protocol = "TCP" },
        @{ Name = "CertWebService-HTTPS-$HttpsPort"; Port = $HttpsPort; Protocol = "TCP" }
    )
    
    foreach ($rule in $firewallRules) {
        if (Get-NetFirewallRule -DisplayName $rule.Name -ErrorAction SilentlyContinue) {
            Remove-NetFirewallRule -DisplayName $rule.Name
        }
        New-NetFirewallRule -DisplayName $rule.Name -Direction Inbound -Protocol $rule.Protocol -LocalPort $rule.Port -Action Allow | Out-Null
        Write-Log "Firewall-Regel erstellt: $($rule.Name)"
    }
    
    # Site starten
    Write-Log "Starte IIS-Site..."
    try {
        $site = Get-Website -Name $SiteName -ErrorAction SilentlyContinue
        if ($site) {
            if ($site.State -ne "Started") {
                Start-Website -Name $SiteName
                Write-Log "IIS-Site gestartet"
            } else {
                Write-Log "IIS-Site bereits gestartet"
            }
        } else {
            Write-Log "Warnung: Site nicht gefunden" "WARNING"
        }
    } catch {
        Write-Log "Warnung beim Site-Start: $($_.Exception.Message)" "WARNING"
        # Trotzdem fortfahren, da Site möglicherweise bereits läuft
    }
    
    # Test
    Write-Log "Teste Installation..."
    Start-Sleep -Seconds 3
    
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:$HttpPort/health.json" -UseBasicParsing -TimeoutSec 10
        if ($response.StatusCode -eq 200) {
            Write-Log "✅ Test erfolgreich - HTTP OK"
        } else {
            Write-Log "⚠️ Test-Warnung - HTTP Status: $($response.StatusCode)" "WARNING"
        }
    } catch {
        Write-Log "⚠️ Test-Fehler: $($_.Exception.Message)" "WARNING"
    }
    
    # Erfolgsmeldung
    Write-Log ""
    Write-Log "=== INSTALLATION ERFOLGREICH ==="
    Write-Log "Certificate WebService ($ServerType) installiert:"
    Write-Log "  HTTP:  http://$env:COMPUTERNAME`:$HttpPort"
    Write-Log "  HTTPS: https://$env:COMPUTERNAME`:$HttpsPort"
    Write-Log "  Pfad:  $InstallPath"
    Write-Log "  Logs:  $logFile"
    Write-Log ""
    
    exit 0
    
} catch {
    Write-Log "❌ INSTALLATION FEHLGESCHLAGEN: $($_.Exception.Message)" "ERROR"
    
    # Cleanup bei Fehler
    try {
        if (Get-Website -Name $SiteName -ErrorAction SilentlyContinue) {
            Remove-Website -Name $SiteName
            Write-Log "Site '$SiteName' entfernt (Cleanup)"
        }
    } catch {
        Write-Log "Cleanup-Fehler: $_" "WARNING"
    }
    
    exit 1
}